data_base_path = './' # Points to a super-directory of data set files. 
                      # E.g. <data_base_path>/uci/yacht.mat
model_base_path = ''  # A folder for storing model save files.
                      # By default, trained models are automatically saved here 
		      #  in case one needs to be re-used or inspected.

